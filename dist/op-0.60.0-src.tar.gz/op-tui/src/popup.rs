//! Fenêtre flottante à onglets : cadre, barre d'onglets, pied de page.
//!
//! Les trois bouts se répètent à l'identique dans chaque projet, et c'est
//! l'ensemble qui fait la structure lisible : sans la barre d'onglets, rien
//! n'indiquait que la fenêtre en avait trois ni lequel était actif ; sans pied,
//! la navigation d'onglets n'était annoncée nulle part.

use std::borrow::Cow;

use ratatui::{
    layout::{Alignment, Constraint, Direction, Layout, Rect},
    style::Style,
    text::{Line, Span},
    widgets::Paragraph,
    Frame,
};

use crate::{
    layout::popup_rect,
    overlay::cadre_titre,
    theme::Popup as Theme,
};

/// Une fenêtre flottante composée : cadre, onglets, pied.
///
/// Le contenu n'est pas rendu ici : [`Fenetre::rendu`] renvoie l'intérieur,
/// qui reste le seul endroit où un projet écrit son contenu.
#[derive(Debug, Clone)]
pub struct Fenetre<'a>
  {
    titre: Cow<'a, str>,
    theme: Theme,
    onglets: &'a [Cow<'a, str>],
    onglet_actif: usize,
    pied: Cow<'a, str>,
    style_onglets: Style,
    style_pied: Style,
  }

impl<'a> Fenetre<'a>
  {
    /// Fenêtre sans onglet ni pied : juste un cadre titré.
    pub fn nouveau(titre: impl Into<Cow<'a, str>>, theme: Theme) -> Self
      {
        Fenetre {
          titre: titre.into(),
          theme,
          onglets: &[],
          onglet_actif: 0,
          pied: Cow::Borrowed(""),
          style_onglets: Style::default(),
          style_pied: Style::default(),
        }
      }

    /// Ajoute la barre d'onglets. `libelles` détermine l'ordre à l'écran.
    pub fn avec_onglets(mut self, libelles: &'a [Cow<'a, str>], actif: usize) -> Self
      {
        self.onglets = libelles;
        self.onglet_actif = actif;
        self
      }

    /// Ajoute le pied centré.
    pub fn avec_pied(mut self, pied: impl Into<Cow<'a, str>>) -> Self
      {
        self.pied = pied.into();
        self
      }

    /// Style de la barre d'onglets.
    pub fn style_onglets(mut self, style: Style) -> Self
      {
        self.style_onglets = style;
        self
      }

    /// Style du pied.
    pub fn style_pied(mut self, style: Style) -> Self
      {
        self.style_pied = style;
        self
      }

    /// Compose la fenêtre et renvoie la zone de contenu.
    ///
    /// `None` quand le terminal est trop petit pour une fenêtre lisible : mieux
    /// vaut ne rien afficher qu'un cadre vide qui masque tout et ne dit rien.
    /// La largeur et la hauteur sont les valeurs *souhaitées* ; la fenêtre les
    /// borne au terminal.
    pub fn rendu(
        &self,
        f: &mut Frame,
        size: Rect,
        largeur: u16,
        hauteur: u16,
      ) -> Option<Rect>
      {
        let area = popup_rect(size, largeur, hauteur)?;
        let inner = cadre_titre(f, area, || self.titre.to_string(), self.theme);
        if self.onglets.is_empty()
          {
            // Pas d'onglets : tout l'intérieur appartient au contenu.
            return Some(inner);
          }
        // Un seul découpage pour les trois zones : la barre et le pied
        // occupent exactement les lignes demandées, le contenu prend le reste,
        // jusqu'à zéro ligne.
        let zones = Layout::default()
          .direction(Direction::Vertical)
          .constraints([
            Constraint::Length(1),
            Constraint::Min(0),
            Constraint::Length(u16::from(!self.pied.is_empty())),
          ])
          .split(inner);
        f.render_widget(
          Paragraph::new(Line::from(
            self.onglets
              .iter()
              .enumerate()
              .map(|(i, libelle)| {
                let marqueur = if i == self.onglet_actif { "▸" } else { " " };
                Span::raw(format!(" {marqueur} {libelle} "))
              })
              .collect::<Vec<Span>>(),
          ))
          .style(self.style_onglets),
          zones[0],
        );
        if !self.pied.is_empty()
          {
            f.render_widget(
              Paragraph::new(self.pied.as_ref())
                .style(self.style_pied)
                .alignment(Alignment::Center),
              zones[2],
            );
          }
        Some(zones[1])
      }
  }

#[cfg(test)]
mod tests
  {
    use super::*;
    use ratatui::{backend::TestBackend, buffer::Buffer, Terminal};

    fn texte(buf: &Buffer) -> String
      {
        (0..buf.area.height)
          .map(|y| (0..buf.area.width).map(|x| buf[(x, y)].symbol()).collect::<String>())
          .collect::<Vec<_>>()
          .join("\n")
      }

    fn libelles() -> [Cow<'static, str>; 3]
      {
        [
          Cow::Borrowed("Projet"),
          Cow::Borrowed("Coûts"),
          Cow::Borrowed("Paramètres"),
        ]
      }

    #[test]
    fn la_fenetre_affiche_titre_onglets_et_pied()
      {
        let onglets = libelles();
        let mut term = Terminal::new(TestBackend::new(60, 16)).unwrap();
        let mut contenu = Rect::default();
        term.draw(|f| {
          contenu = Fenetre::nouveau("Projet", Theme::SOMBRE)
            .avec_onglets(&onglets, 1)
            .avec_pied(" Tab : onglets ")
            .style_onglets(Style::default())
            .rendu(f, f.area(), 40, 12)
            .unwrap();
          f.render_widget(Paragraph::new("CONTENU"), contenu);
        })
        .unwrap();
        let rendu = texte(term.backend().buffer());
        assert!(rendu.contains(" Projet "), "titre :\n{rendu}");
        assert!(rendu.contains(" ▸ Coûts "), "onglet actif marque :\n{rendu}");
        assert!(rendu.contains("   Projet "), "onglet inactif :\n{rendu}");
        assert!(rendu.contains(" Tab : onglets "), "pied :\n{rendu}");
        assert!(rendu.contains("CONTENU"), "contenu :\n{rendu}");
      }

    /// Le contenu doit être entre les deux barres, pas dessous.
    #[test]
    fn le_contenu_tombe_entre_les_barres()
      {
        let onglets = libelles();
        let mut term = Terminal::new(TestBackend::new(60, 16)).unwrap();
        let mut contenu = Rect::default();
        term.draw(|f| {
          contenu = Fenetre::nouveau("T", Theme::SOMBRE)
            .avec_onglets(&onglets, 0)
            .avec_pied("pied")
            .rendu(f, f.area(), 40, 12)
            .unwrap();
        })
        .unwrap();
        // La fenêtre est centrée : x = (60 - 40) / 2 + 1 (bordure gauche),
        // y = (16 - 12) / 2 + 1 (bordure haute) + 1 (barre d'onglets).
        assert_eq!((contenu.x, contenu.y), (11, 4));
        assert_eq!(contenu.height, 8, "12 - 2 (cadre) - 1 (onglets) - 1 (pied)");
      }

    #[test]
    fn un_terminal_trop_petit_ne_dessine_rien()
      {
        let mut term = Terminal::new(TestBackend::new(10, 3)).unwrap();
        let mut ok = true;
        term.draw(|f| {
          ok = Fenetre::nouveau("T", Theme::SOMBRE)
            .avec_pied("pied")
            .rendu(f, f.area(), 40, 12)
            .is_some();
        })
        .unwrap();
        assert!(!ok, "rien ne doit etre rendu sur un terminal trop petit");
        assert!(!texte(term.backend().buffer()).contains('T'));
      }

    #[test]
    fn une_fenetre_sans_onglet_laisse_toute_la_place_au_contenu()
      {
        let mut term = Terminal::new(TestBackend::new(60, 16)).unwrap();
        let mut contenu = Rect::default();
        term.draw(|f| {
          contenu = Fenetre::nouveau("T", Theme::SOMBRE).rendu(f, f.area(), 40, 12).unwrap();
        })
        .unwrap();
        assert_eq!(contenu.height, 10, "12 - 2 (cadre)");
        assert!(texte(term.backend().buffer()).contains('┌'));
      }
  }
