//! Fenêtres de défilement : bornage, décalage, tranches visibles.
//!
//! Une liste plus courte que sa fenêtre n'a rien à faire défiler, et une
//! fenêtre qui déborde de la liste doit afficher le bas de la liste — pas une
//! page vide. C'est le défaut classique d'un `skip(decalage).take(visibles)`
//! sans bornage : le décorateur d'un `End` à `usize::MAX` vide l'écran au
//! lieu d'amener à la fin.

/// Décalage « aussi bas que possible », à borner au moment du rendu.
///
/// Le handler de touche ne connaît pas la taille du contenu — elle n'est
/// calculée qu'au rendu, quand les lignes existent. Il pose donc cette
/// valeur, et le rendu la ramène dans les bornes via [`borner`].
pub const FIN: usize = usize::MAX;

/// Décalage maximal : la fenêtre se referme sur la dernière ligne.
///
/// Zéro dès que le contenu tient dans la fenêtre : faire défiler un contenu
/// qui n'en a pas besoin décale le tableau pour montrer du vide.
pub fn max_scroll(total: usize, visibles: usize) -> usize
  {
    borner(FIN, total, visibles)
  }

/// Ramène `offset` dans la plage qui garde la fenêtre à l'intérieur du contenu.
///
/// Le haut est forcé à zéro, et le bas à `total - visibles`. Un `offset`
/// absurde — le sentinelle [`FIN`], un `usize::MAX` venue d'un `End` répété —
/// donne donc la dernière position valide au lieu d'un écran vide.
pub fn borner(offset: usize, total: usize, visibles: usize) -> usize
  {
    if visibles == 0 || total <= visibles
      {
        return 0;
      }
    offset.min(total - visibles)
  }

/// Décale un défilement de `pas` lignes, sans jamais passer sous zéro.
///
/// `pas` négatif remonte. Les deux sens saturent : le `+` non saturant d'un
/// défilement qui part du sentinelle [`FIN`] déborde en build de debug.
pub fn decaler(offset: usize, pas: isize) -> usize
  {
    if pas < 0
      {
        offset.saturating_sub(pas.unsigned_abs())
      }
    else
      {
        offset.saturating_add(pas as usize)
      }
  }

/// Les éléments visibles dans la fenêtre courante, bornés comme le rendu.
///
/// Le `skip`/`take` seul laisse passer un décalage hors bornes et renvoie une
/// tranche vide : l'écran clignote vide au lieu d'afficher le contenu.
pub fn fenetre<T>(elements: &[T], offset: usize, visibles: usize) -> &[T]
  {
    if visibles == 0
      {
        return &[];
      }
    let debut = borner(offset, elements.len(), visibles);
    let fin = debut.saturating_add(visibles).min(elements.len());
    &elements[debut..fin]
  }

#[cfg(test)]
mod tests
  {
    use super::*;

    #[test]
    fn un_contenu_plus_court_que_la_fenetre_ne_borne_pas()
      {
        assert_eq!(borner(0, 3, 10), 0);
        assert_eq!(borner(7, 3, 10), 0);
        assert_eq!(borner(FIN, 3, 10), 0);
        assert_eq!(max_scroll(3, 10), 0);
      }

    #[test]
    fn la_fenetre_va_jusqu_au_dernier_element()
      {
        // 10 éléments, 4 visibles : la dernière position montre 6..10.
        assert_eq!(max_scroll(10, 4), 6);
        assert_eq!(borner(FIN, 10, 4), 6);
        assert_eq!(borner(3, 10, 4), 3, "un décalage valide est conservé");
        assert_eq!(borner(99, 10, 4), 6, "au-delà, on montre la fin");
      }

    #[test]
    fn une_fenetre_vide_ne_provoque_pas_de_sous_flux()
      {
        assert_eq!(borner(5, 10, 0), 0);
        assert_eq!(max_scroll(10, 0), 0);
        assert!(fenetre(&[1, 2, 3], 0, 0).is_empty());
      }

    #[test]
    fn un_contenu_vide_ne_borne_pas()
      {
        assert_eq!(borner(FIN, 0, 5), 0);
        assert_eq!(max_scroll(0, 5), 0);
        assert!(fenetre::<u8>(&[], FIN, 5).is_empty());
      }

    /// Le bug récurrent : `End` posait un décalage hors bornes et le rendu
    /// affichait une page vide au lieu de la fin de la liste.
    #[test]
    fn la_fenetre_reste_pleine_meme_avec_le_sentinelle()
      {
        let elements: Vec<usize> = (0..10).collect();
        let vue = fenetre(&elements, FIN, 4);
        assert_eq!(vue, &[6, 7, 8, 9], "la fin doit etre visible, pas le vide");
        assert_eq!(vue.len(), 4);
      }

    #[test]
    fn la_fenetre_renvoie_ce_qui_tient()
      {
        let elements: Vec<usize> = (0..5).collect();
        assert_eq!(fenetre(&elements, 0, 3), &[0, 1, 2]);
        assert_eq!(fenetre(&elements, 2, 3), &[2, 3, 4], "fenetre partielle en bas");
        assert_eq!(fenetre(&elements, 0, 10), &[0, 1, 2, 3, 4], "tout tient");
      }

    #[test]
    fn decaler_sature_dans_les_deux_sens()
      {
        assert_eq!(decaler(0, -1), 0, "on ne passe pas sous zero");
        assert_eq!(decaler(0, -10), 0);
        assert_eq!(decaler(3, 1), 4);
        assert_eq!(decaler(3, -2), 1);
        assert_eq!(decaler(FIN, 1), FIN, "le sentinelle ne deborde pas");
        assert_eq!(decaler(FIN, -1), FIN - 1);
        assert_eq!(decaler(0, 0), 0);
      }
  }
