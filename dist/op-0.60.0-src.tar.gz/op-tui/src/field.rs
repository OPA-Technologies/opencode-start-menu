//! Champs de formulaire : valeur affichée et position du curseur.
//!
//! La valeur affichée et la colonne du curseur étaient deux pièges déjà payés
//! dans un projet, et il fallait les écrire correctement à chaque fois. Le
//! champ montre la frappe en cours avant validation, et le curseur se place
//! selon la largeur *rendue* du texte, pas son nombre de caractères.

use ratatui::text::Line;

/// Texte d'un champ vide, en guise de valeur.
pub const VIDE: &str = "(vide)";

/// Valeur réellement affichée pour un champ de formulaire.
///
/// La frappe en cours (`buffer`) prime sur la valeur validée (`valide`) :
/// c'est la règle qui manquait au formulaire de création, où seule la valeur
/// validée à Entrée était peinte. Le texte tapé atterrissait dans `buffer`,
/// donc rien ne bougeait à l'écran avant validation — la saisie était
/// aveugle, alors que le curseur, lui, suivait bien `input_offset`.
pub fn valeur_affiche(valide: &str, buffer: &str, en_saisie: bool, placeholder: &str) -> String
  {
    let source = if en_saisie { buffer } else { valide };
    if source.trim().is_empty() {
      placeholder.to_string()
    }
    else
      {
        source.to_string()
      }
  }

/// Colonne d'affichage du curseur dans un champ.
///
/// `offset` compte des caractères, pas des colonnes. L'utiliser tel quel
/// décale le curseur de droite sur tout caractère large (`é`, `→`, caractères
/// CJK…), et de gauche sur les caractères de largeur nulle.
pub fn colonne_curseur(buffer: &str, offset: usize) -> usize
  {
    let octets = octet_pour_caractere(buffer, offset);
    let prefixe = buffer.get(..octets).unwrap_or(buffer);
    // `Line::width` mesure la largeur d'affichage réelle (une colonne par
    // cellule), contrairement à `chars().count()`.
    Line::from(prefixe).width()
  }

/// Index d'octet du n-ième caractère, borné à la longueur du texte.
///
/// Un offset issu d'une frappe peut dépasser la longueur du buffer — une
/// sélection remplacée, un caractère large compté deux fois. Le slicing sur un
/// index d'octet au milieu d'un caractère panic : d'où l'arrondi par groupe de
/// caractères, jamais par octet.
pub fn octet_pour_caractere(texte: &str, n: usize) -> usize
  {
    texte
      .char_indices()
      .nth(n)
      .map_or_else(|| texte.len(), |(octet, _)| octet)
  }

#[cfg(test)]
mod tests
  {
    use super::*;

    #[test]
    fn la_frappe_prime_sur_la_valeur_validee()
      {
        assert_eq!(valeur_affiche("1.0.0", "1.0.1", true, VIDE), "1.0.1");
        assert_eq!(valeur_affiche("1.0.0", "1.0.1", false, VIDE), "1.0.0");
      }

    #[test]
    fn un_champ_vide_donne_un_vide()
      {
        assert_eq!(valeur_affiche("", "", false, VIDE), "(vide)");
        assert_eq!(valeur_affiche("  ", "  ", false, VIDE), "(vide)", "espaces seuls");
        assert_eq!(valeur_affiche("", "", true, VIDE), "(vide)", "frappe vide en cours");
      }

    #[test]
    fn le_curseur_suit_la_largeur_affichee()
      {
        assert_eq!(colonne_curseur("abc", 0), 0);
        assert_eq!(colonne_curseur("abc", 3), 3);
        // Un caractère CJK occupe deux colonnes.
        assert_eq!(colonne_curseur("漢", 1), 2);
        assert_eq!(colonne_curseur("漢漢", 2), 4);
        // `é` et `→` ne font qu'une colonne : compter au caractère se trouve
        // juste par hasard.
        assert_eq!(colonne_curseur("é→", 2), 2);
      }

    /// Le bug récurrent : compter les caractères décale le curseur de droite
    /// dès qu'un caractère large apparaît.
    #[test]
    fn un_prefixe_large_decale_le_curseur_de_la_bonne_maniere()
      {
        let texte = "a漢b";
        assert_eq!(colonne_curseur(texte, 3), 4, "trois caractères, quatre colonnes");
        assert_eq!(colonne_curseur(texte, 2), 3);
      }

    /// Un offset hors bornes ne doit pas paniquer : il arrive quand la frappe
    /// remplace une sélection.
    #[test]
    fn un_curseur_hors_bornes_ne_panique_pas()
      {
        assert_eq!(colonne_curseur("abc", 99), 3);
        assert_eq!(colonne_curseur("", 5), 0);
        assert_eq!(colonne_curseur("é", 1), 1);
      }

    #[test]
    fn octet_pour_caractere_ne_tombe_pas_au_milieu_d_un_caractere()
      {
        assert_eq!(octet_pour_caractere("aé", 0), 0);
        assert_eq!(octet_pour_caractere("aé", 1), 1);
        assert_eq!(octet_pour_caractere("aé", 2), 3);
        assert_eq!(octet_pour_caractere("aé", 9), 3);
      }
  }
