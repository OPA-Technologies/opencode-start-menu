//! Rendu des aides : la barre d'une ligne, et l'écran complet.
//!
//! Les deux sont des rendus du même jeu de raccourcis, jamais deux listes
//! écrites à la main. La barre tronque ce qui ne tient pas et dit où trouver
//! le reste ; l'écran complet, lui, défile.

use ratatui::{
    layout::Rect,
    style::Style,
    text::{Line, Span},
    widgets::Paragraph,
    Frame,
};

use crate::keymap::{Cible, Raccourci};


/// Séparateur entre deux raccourcis dans la barre.
pub const SEPARATEUR: &str = " · ";

/// Barre contextuelle : une ligne, les gestes du mode courant.
///
/// `suffixe` désigne la touche qui ouvre l'aide complète (`F1 aide`). Sa place
/// est réservée d'emblée, et il n'est ajouté que si la ligne a réellement été
/// tronquée : c'est lui qui signale que la barre est incomplète, donc le
/// couper revient à ne plus rien signaler du tout.
///
/// Si le suffixe annonce une touche déjà présente dans la liste, il est
/// inutile : la barre afficherait « F1 Aide … F1 aide ».
pub fn barre(
    f: &mut Frame,
    area: Rect,
    cible: &dyn Cible,
    suffixe: &str,
    style: Style,
  )
  {
    let raccourcis = cible.contextuel();
    let largeur_max = usize::from(area.width)
      .saturating_sub(largeur(suffixe).saturating_add(largeur(SEPARATEUR)));
    let mut texte = String::new();
    let mut tronque = false;
    let mut affiches: Vec<&Raccourci> = Vec::new();
    for r in &raccourcis
      {
        let morceau = r.ligne();
        let sep = if texte.is_empty() { 0 } else { largeur(SEPARATEUR) };
        if largeur(&texte).saturating_add(sep).saturating_add(largeur(&morceau)) > largeur_max
          {
            tronque = true;
            break;
          }
        if !texte.is_empty()
          {
            texte.push_str(SEPARATEUR);
          }
        texte.push_str(&morceau);
        affiches.push(r);
      }
    // Ce qui n'a pas tenu n'est pas perdu : le suffixe indique où le retrouver.
    //
    // La question ne porte que sur ce qui est *affiché*. Une liste dont `F1`
    // arrive en dernier est précisément le cas où le suffixe est indispensable :
    // `F1` est déclarée mais n'a pas eu la place, donc chercher `F1` dans la
    // déclaration donnerait un « déjà annoncé » faux, et la barre tronquée
    // ne renverrait nulle part.
    let cle = suffixe.split_whitespace().next().unwrap_or("");
    if tronque && !cle.is_empty() && !affiches.iter().any(|r| r.repond_a(cle))
      {
        if !texte.is_empty()
          {
            texte.push_str(SEPARATEUR);
          }
        texte.push_str(suffixe);
      }
    f.render_widget(
      Paragraph::new(texte)
        .style(style)
        .alignment(ratatui::layout::Alignment::Center),
      area,
    );
  }

/// Lignes de l'écran d'aide : la vue contextuelle, ou tous les raccourcis.
///
/// En vue complète, chaque groupe d'écran est un en-tête ; le premier groupe
/// n'est pas répété ligne à ligne, sinon l'écran serait deux fois plus long que
/// la liste qu'il contient.
pub fn lignes(
    cible: &dyn Cible,
    complet: bool,
    style_texte: Style,
    style_groupe: Style,
) -> Vec<Line<'static>>
  {
    let mut lignes: Vec<Line<'static>> = Vec::new();
    if !complet
      {
        for r in cible.contextuel()
          {
            lignes.push(Line::from(Span::styled(r.ligne_indentee(), style_texte)));
          }
        return lignes;
      }
    let mut precedent: Option<String> = None;
    for (groupe, raccourcis) in cible.complet()
      {
        let groupe = groupe.into_owned();
        if Some(groupe.as_str()) != precedent.as_deref()
          {
            lignes.push(Line::from(Span::styled(groupe.clone(), style_groupe)));
          }
        precedent = Some(groupe);
        for r in raccourcis
          {
            lignes.push(Line::from(Span::styled(r.ligne_indentee(), style_texte)));
          }
      }
    lignes
  }

/// Largeur d'affichage d'un texte, en colonnes.
///
/// `chars().count()` suffit pour du ASCII, et se trompe sur tout le reste :
/// `é` et `→` font une colonne, un idéogramme en fait deux. Une barre qui
/// compte mal déborde du terminal au lieu de se tronquer.
fn largeur(texte: &str) -> usize
  {
    Line::from(texte).width()
  }

#[cfg(test)]
mod tests
  {
    use super::*;
    use crate::keymap::{raccourci, Raccourci};
    use ratatui::{backend::TestBackend, buffer::Buffer, Terminal};

    struct Ecran;

    impl Cible for Ecran
      {
        fn contextuel(&self) -> Vec<Raccourci>
          {
            vec![
              raccourci("↑/↓", "Naviguer"),
              raccourci("Entrée", "Ouvrir"),
              raccourci("p", "Réglages projet"),
              raccourci("c", "Coûts"),
              raccourci("s", "Préférences"),
              raccourci("m", "Module"),
              raccourci("n", "Nouveau"),
              raccourci("r", "Rafraîchir"),
              raccourci("F1", "Aide"),
            ]
          }

        fn complet(&self) -> Vec<(std::borrow::Cow<'static, str>, Vec<Raccourci>)>
          {
            use std::borrow::Cow;
            vec![
              (
                Cow::Borrowed("Liste des projets"),
                vec![raccourci("Entrée", "Ouvrir dans opencode"), raccourci("q", "Quitter")],
              ),
              (
                Cow::Borrowed("Popup — onglet Coûts"),
                vec![raccourci("r", "Rafraîchir la source"), raccourci("Échap", "Fermer")],
              ),
            ]
          }
      }

    fn texte(buf: &Buffer) -> String
      {
        (0..buf.area.height)
          .map(|y| (0..buf.area.width).map(|x| buf[(x, y)].symbol()).collect::<String>())
          .collect::<Vec<_>>()
          .join("\n")
      }

    fn barre_rendue(largeur: u16) -> String
      {
        let mut term = Terminal::new(TestBackend::new(largeur, 3)).unwrap();
        term.draw(|f| {
          barre(
            f,
            Rect { x: 0, y: 1, width: largeur, height: 1 },
            &Ecran,
            "F1 aide",
            Style::default(),
          )
        })
        .unwrap();
        texte(term.backend().buffer())
      }

    #[test]
    fn la_barre_annonce_tout_le_mode_si_la_place_le_permet()
      {
        let rendu = barre_rendue(200);
        assert!(rendu.contains("↑/↓ Naviguer"), "{rendu}");
        assert!(rendu.contains("F1 Aide"), "{rendu}");
      }

    /// Le défaut historique : la barre tronquée disparaissait sans rien dire,
    /// et l'utilisateur cherchait une touche que l'aide ne donnait pas.
    #[test]
    fn une_barre_tronquee_renvoie_vers_l_aide()
      {
        let rendu = barre_rendue(40);
        assert!(rendu.contains("F1 aide"), "le suffixe manque : {rendu}");
        assert!(rendu.contains("↑/↓ Naviguer"), "{rendu}");
      }

    /// Le suffixe est réservé d'emblée : sans cette marge, il déborde à son
    /// tour et la barre ne dit plus du tout où trouver le reste.
    #[test]
    fn la_place_du_suffixe_est_reservee_d_emblee()
      {
        let rendu = barre_rendue(40);
        assert!(!rendu.contains("F1 aide ·"), "suffixe dupliqué : {rendu}");
        assert_eq!(rendu.matches("F1 aide").count(), 1, "{rendu}");
      }

    /// Quand la touche du suffixe est *déjà affichée*, l'ajouter ferait
    /// doublon : la barre dirait deux fois `F1`.
    #[test]
    fn le_suffixe_est_inutile_si_la_touche_est_deja_affichee()
      {
        let mut term = Terminal::new(TestBackend::new(40, 3)).unwrap();
        struct Court;
        impl Cible for Court
          {
            fn contextuel(&self) -> Vec<Raccourci>
              {
                vec![
            raccourci("F1", "Aide contextuelle"),
            raccourci("Entrée", "Ouvrir"),
            raccourci("Tab/⇧Tab", "Onglet suivant/précédent"),
          ]
              }

            fn complet(&self) -> Vec<(std::borrow::Cow<'static, str>, Vec<Raccourci>)>
              {
                vec![]
              }
          }
        term.draw(|f| {
          barre(
            f,
            Rect { x: 0, y: 1, width: 40, height: 1 },
            &Court,
            "F1 aide",
            Style::default(),
          )
        })
        .unwrap();
        let rendu = texte(term.backend().buffer());
        assert_eq!(rendu.matches("F1").count(), 1, "F1 ne doit pas apparaitre deux fois : {rendu}");
        assert!(!rendu.contains("aide "), "{rendu}");
      }

    #[test]
    fn une_barre_sans_rien_a_annoncer_reste_vide()
      {
        struct Vide;
        impl Cible for Vide
          {
            fn contextuel(&self) -> Vec<Raccourci>
              {
                vec![]
              }

            fn complet(&self) -> Vec<(std::borrow::Cow<'static, str>, Vec<Raccourci>)>
              {
                vec![]
              }
          }
        let mut term = Terminal::new(TestBackend::new(40, 3)).unwrap();
        term.draw(|f| {
          barre(
            f,
            Rect { x: 0, y: 1, width: 40, height: 1 },
            &Vide,
            "F1 aide",
            Style::default(),
          )
        })
        .unwrap();
        assert!(texte(term.backend().buffer()).trim().is_empty());
      }

    #[test]
    fn la_vue_contextuelle_ne_met_pas_d_en_tete()
      {
        let lignes = lignes(&Ecran, false, Style::default(), Style::default());
        assert_eq!(lignes.len(), 9);
        assert!(lignes[0].to_string().contains("↑/↓  Naviguer"), "{:?}", lignes[0]);
      }

    #[test]
    fn la_vue_complete_annonce_chaque_ecran_une_seule_fois()
      {
        let lignes = lignes(
          &Ecran,
          true,
          Style::default(),
          Style::default().add_modifier(ratatui::style::Modifier::BOLD),
        );
        // 2 en-têtes + 2 raccourcis par écran.
        assert_eq!(lignes.len(), 6);
        assert_eq!(lignes[0].to_string(), "Liste des projets");
        assert!(lignes[1].to_string().contains("  Entrée  Ouvrir dans opencode"));
        assert_eq!(lignes[3].to_string(), "Popup — onglet Coûts");
      }

    /// La largeur d'une colonne n'est pas une longueur en octets, ni même un
    /// nombre de caractères.
    #[test]
    fn la_largeur_compte_les_colonnes_pas_les_caracteres()
      {
        assert_eq!(largeur("abc"), 3);
        assert_eq!(largeur("é→"), 2);
        assert_eq!(largeur("漢"), 2);
        assert_eq!(largeur(SEPARATEUR), 3);
      }
  }
