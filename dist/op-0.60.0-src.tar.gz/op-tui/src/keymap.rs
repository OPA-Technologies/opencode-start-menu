//! Raccourcis clavier : la déclaration, et le contrat qui la rend réutilisable.
//!
//! Une aide dupliquée à la main finit toujours par annoncer des touches qui
//! n'existent plus. Ces raccourcis sont donc déclarés une fois, et l'aide est un
//! rendu de cette déclaration.
//!
//! Le crate ne sait pas ce qu'est un « mode » ni un « onglet » : il expose le
//! contrat [`Cible`], et chaque projet implémente le sien.

use std::borrow::Cow;

/// Un raccourci : la touche telle qu'elle se lit, et ce qu'elle fait.
///
/// Les champs sont [`Cow`] pour accepter aussi bien une constante de code
/// qu'une chaîne lue dans un fichier de configuration, sans copie dans le
/// premier cas — la barre du bas est redessinée à chaque image.
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct Raccourci
  {
    /// Touches affichées, séparées par `/` quand plusieurs touches marchent.
    pub touche: Cow<'static, str>,
    /// Effet, à la troisième personne : « Naviguer », « Ouvrir ».
    pub libelle: Cow<'static, str>,
  }

/// Raccourci construit à partir de deux constantes.
pub fn raccourci(touche: &'static str, libelle: &'static str) -> Raccourci
  {
    Raccourci {
      touche: Cow::Borrowed(touche),
      libelle: Cow::Borrowed(libelle),
    }
  }

/// Raccourci construit à partir de chaînes possédées.
///
/// `Cow::Owned` ici : le raccourci vient d'une lecture, pas du code.
pub fn raccourci_texte(touche: String, libelle: String) -> Raccourci
  {
    Raccourci {
      touche: Cow::Owned(touche),
      libelle: Cow::Owned(libelle),
    }
  }

impl Raccourci
  {
    /// La touche, pour comparer sans court-circuiter sur le `Cow`.
    pub fn touche(&self) -> &str
      {
        self.touche.as_ref()
      }

    /// Le libellé, pour comparer sans court-circuiter sur le `Cow`.
    pub fn libelle(&self) -> &str
      {
        self.libelle.as_ref()
      }

    /// Rendu compact « Touche Libellé », pour une barre d'une seule ligne.
    pub fn ligne(&self) -> String
      {
        format!("{} {}", self.touche, self.libelle)
      }

    /// Rendu aéré « Touche  Libellé », pour une liste qui a de la place.
    pub fn ligne_indentee(&self) -> String
      {
        format!("  {}  {}", self.touche, self.libelle)
      }

    /// Cette touche répond-elle à l'une de celles annoncées ?
    ///
    /// Une touche affichée peut en annoncer plusieurs (`↑/↓`, `Tab/⇧Tab`) :
    /// poser la question sur la sous-chaîne entière ferait manquer un `F1`
    /// déjà présent, et le suffixe « F1 aide » viendrait s'y ajouter.
    pub fn repond_a(&self, touche: &str) -> bool
      {
        self.touche.split('/').any(|t| t.trim() == touche)
      }
  }

/// Ce qu'un projet sait de ses raccourcis, sans que le crate le sache.
///
/// Implémentez ce trait pour brancher l'aide de votre application sur les
/// primitives de rendu partagées.
pub trait Cible
  {
    /// Les gestes du mode courant : ce que la barre du bas annonce.
    fn contextuel(&self) -> Vec<Raccourci>;

    /// Tous les gestes, groupés par écran : le contenu de l'aide complète.
    ///
    /// Un groupe par écran, dans l'ordre où l'utilisateur les rencontre.
    fn complet(&self) -> Vec<(Cow<'static, str>, Vec<Raccourci>)>;
  }

#[cfg(test)]
mod tests
  {
    use super::*;

    #[test]
    fn le_rendu_compact_et_le_rendu_indente_different()
      {
        let r = raccourci("Entrée", "Ouvrir");
        assert_eq!(r.ligne(), "Entrée Ouvrir");
        assert_eq!(r.ligne_indentee(), "  Entrée  Ouvrir");
      }

    /// Le suffixe « F1 aide » ne doit pas s'ajouter si `F1` est déjà annoncé :
    /// sans cette question, la barre du popup se terminait par « … F1 aide »
    /// alors qu'elle contenait déjà `F1`.
    #[test]
    fn une_touche_annonce_plusieurs_cas_est_reconnue()
      {
        let r = raccourci("Tab/⇧Tab", "Onglet");
        assert!(r.repond_a("Tab"));
        assert!(r.repond_a("⇧Tab"));
        assert!(!r.repond_a("F1"));
        assert!(!r.repond_a("Ta"), "une sous-chaine ne suffit pas");
        assert!(raccourci("F1", "Aide").repond_a("F1"));
      }

    #[test]
    fn les_chaines_possedees_ne_sont_pas_copiées_tant_qu_on_ne_le_demande_pas()
      {
        let r = raccourci_texte("F2".to_string(), "Renommer".to_string());
        assert_eq!(r.touche(), "F2");
        assert_eq!(r.libelle(), "Renommer");
        assert_eq!(r, raccourci("F2", "Renommer"));
      }

    struct EcranFictif;

    impl Cible for EcranFictif
      {
        fn contextuel(&self) -> Vec<Raccourci>
          {
            vec![raccourci("q", "Quitter")]
          }

        fn complet(&self) -> Vec<(Cow<'static, str>, Vec<Raccourci>)>
          {
            vec![(
              Cow::Borrowed("Liste"),
              vec![raccourci("q", "Quitter"), raccourci("F1", "Aide")],
            )]
          }
      }

    #[test]
    fn une_cible_implémente_tout_le_contrat()
      {
        let cible = EcranFictif;
        assert_eq!(cible.contextuel().len(), 1);
        let groupes = cible.complet();
        assert_eq!(groupes.len(), 1);
        assert_eq!(groupes[0].0, "Liste");
        assert_eq!(groupes[0].1.len(), 2);
      }
  }
