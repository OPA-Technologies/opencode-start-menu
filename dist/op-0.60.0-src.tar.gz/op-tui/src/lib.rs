//! Primitives TUI partagées entre les projets OPA.
//!
//! Les mêmes cadres, onglets, champs et barres d'aide étaient réécrits — et
//! divergaient — d'un projet à l'autre. Une aide dupliquée finit toujours par
//! annoncer des touches qui n'existent plus, et un `Fin` qui pousse un
//! décalage à l'infini finit toujours par vider un tableau. Ces primitives
//! tiennent ces deux cas, une fois pour toutes.
//!
//! Aucun type métier ici : la bibliothèque connaît le cadre, pas le contenu.

pub mod edit;
pub mod field;
pub mod help;
pub mod layout;
pub mod keymap;
pub mod overlay;
pub mod popup;
pub mod theme;
pub mod viewport;

pub use theme::Popup;
