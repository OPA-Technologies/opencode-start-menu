//! Géométrie des fenêtres flottantes.
//!
//! Le calcul « centrer, puis recadrer sur l'écran » était recopié dans chaque
//! popup, avec des variantes : les uns limitaient la largeur, d'autres la
//! hauteur, d'autres encore intersectionnaient et d'autres non. Un popup qui
//! déborde d'une colonne sur un terminal étroit n'était pas rare.

use ratatui::layout::Rect;

/// En dessous de cette largeur, un popup n'affiche plus rien d'utile : mieux
/// vaut ne rien dessiner que peindre un cadre qui masque tout l'écran.
pub const LARGEUR_MIN: u16 = 8;

/// En dessous de cette hauteur, il ne reste que les bordures.
pub const HAUTEUR_MIN: u16 = 5;

/// Rectangle centré dans `area`, aux dimensions demandées.
///
/// Les dimensions sont ramenées à celles de `area` : un popup ne peut pas être
/// plus grand que la fenêtre qui le contient, et demander plus ne doit pas
/// produire un rectangle qui déborde.
pub fn rect_centree(area: Rect, largeur: u16, hauteur: u16) -> Rect
  {
    let largeur = largeur.min(area.width);
    let hauteur = hauteur.min(area.height);
    Rect {
      x: area.x + area.width.saturating_sub(largeur) / 2,
      y: area.y + area.height.saturating_sub(hauteur) / 2,
      width: largeur,
      height: hauteur,
    }
  }

/// Rectangle centré, garanti affichable.
///
/// Renvoie `None` quand la fenêtre est trop petite pour accueillir le popup :
/// dessiner un cadre de trois lignes de haut sur un terminal étroit masque le
/// contenu sans rien montrer à la place. Les appelants rendent alors un simple
/// `return`.
pub fn popup_rect(area: Rect, largeur: u16, hauteur: u16) -> Option<Rect>
  {
    let rect = rect_centree(area, largeur, hauteur).intersection(area);
    if rect.width < LARGEUR_MIN || rect.height < HAUTEUR_MIN
      {
        None
      }
    else
      {
        Some(rect)
      }
  }

#[cfg(test)]
mod tests
  {
    use super::*;

    fn aire(l: u16, h: u16) -> Rect {
      Rect { x: 0, y: 0, width: l, height: h }
    }

    #[test]
    fn le_popup_est_centre()
      {
        let r = rect_centree(aire(80, 24), 40, 10);
        assert_eq!((r.x, r.y), (20, 7));
        assert_eq!((r.width, r.height), (40, 10));
      }

    /// Un décalage impair laisse une colonne de plus à droite : c'est
    /// volontaire, `x` reste un multiple de 2 près du centre.
    #[test]
    fn un_ecart_impair_decale_d_une_colonne()
      {
        let r = rect_centree(aire(81, 25), 40, 11);
        assert_eq!(r.x, 20);
        assert_eq!(r.y, 7);
      }

    #[test]
    fn un_popup_plus_grand_que_l_ecran_est_retremci()
      {
        let r = rect_centree(aire(40, 10), 200, 100);
        assert_eq!(r, aire(40, 10));
      }

    #[test]
    fn le_rectangle_reste_dans_une_aire_decallee()
      {
        let depart = Rect { x: 10, y: 5, width: 60, height: 20 };
        let r = rect_centree(depart, 20, 6);
        assert_eq!(r, Rect { x: 30, y: 12, width: 20, height: 6 });
      }

    #[test]
    fn un_ecran_trop_etroit_ne_donne_aucun_popup()
      {
        assert!(popup_rect(aire(6, 20), 40, 10).is_none(), "moins de 8 colonnes");
        assert!(popup_rect(aire(80, 4), 40, 10).is_none(), "moins de 5 lignes");
      }

    #[test]
    fn un_ecran_assez_grand_donne_un_popup_affichable()
      {
        let r = popup_rect(aire(80, 24), 40, 10).unwrap();
        assert_eq!((r.width, r.height), (40, 10));
      }

    /// Le popup ne déborde jamais, même sur un terminal plus petit que la
    /// largeur demandée : c'est ce que le retrempi garantit.
    #[test]
    fn le_popup_ne_deborde_jamais()
      {
        for (l, h) in [(20u16, 6u16), (40, 12), (9, 5), (8, 5)]
          {
            let a = aire(l, h);
            let r = popup_rect(a, 100, 30).unwrap();
            assert!(r.x >= a.x && r.y >= a.y, "origine hors zone en {l}x{h}");
            assert!(r.x + r.width <= a.x + a.width, "débordement en largeur en {l}x{h}");
            assert!(r.y + r.height <= a.y + a.height, "débordement en hauteur en {l}x{h}");
          }
      }
  }
