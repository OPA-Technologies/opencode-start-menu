//! Couleurs d'un popup.
//!
//! Les deux projets n'utilisent pas le même fond — l'un noircit, l'autre
//! gris foncé — et un composant Popup qui coderait le noir en dur
//! changerait le rendu de l'autre. La couleur passe donc par le thème.

use ratatui::style::Color;

/// Palette d'un popup et de ses éléments périphériques.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Popup
  {
    /// Fond du cadre : repeint la zone pour qu'aucun contenu ne transparaît.
    pub fond: Color,
    /// Couleur du trait de bordure.
    pub bordure: Color,
    /// Avertissements et messages d'absence.
    pub alerte: Color,
    /// Barre d'aide, libellés secondaires.
    pub aide: Color,
  }

impl Popup
  {
    /// Fond noir, bordure cyan : le thème du menu de démarrage.
    pub const SOMBRE: Self =
      Self { fond: Color::Black, bordure: Color::Cyan, alerte: Color::Yellow, aide: Color::DarkGray };

    /// Fond gris foncé, bordure cyan : le thème du dessinateur.
    pub const GRIS: Self =
      Self { fond: Color::DarkGray, bordure: Color::Cyan, alerte: Color::Yellow, aide: Color::Gray };
  }

impl Default for Popup
  {
    fn default() -> Self
      {
        Self::SOMBRE
      }
  }

#[cfg(test)]
mod tests
  {
    use super::*;

    #[test]
    fn les_deux_themes_ne_different_que_par_le_fond()
      {
        assert_eq!(Popup::SOMBRE.bordure, Popup::GRIS.bordure);
        assert_eq!(Popup::SOMBRE.alerte, Popup::GRIS.alerte);
        assert_ne!(Popup::SOMBRE.fond, Popup::GRIS.fond);
        assert_eq!(Popup::default(), Popup::SOMBRE);
      }
  }
