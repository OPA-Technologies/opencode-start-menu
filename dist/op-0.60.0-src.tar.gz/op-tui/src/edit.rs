//! Édition de ligne : tampon, curseur et gestes standards d'un éditeur.
//!
//! Les mêmes déplacements — d'un mot, des extrêmes, de la suppression —
//! étaient réécrits champ par champ, avec à chaque fois un écrasement du
//! texte existant au premier caractère. Le champ se comporte désormais comme
//! tout champ de texte : la frappe continue le texte là où est le curseur,
//! `Retour arrière` et `Suppr` agissent dès la première touche.
//!
//! Le module ne connaît pas `crossterm` : l'application traduit ses touches
//! en [`Touche`], ce qui garde la bibliothèque indépendante du terminal.

/// Ce qui intéresse un champ texte, une fois le terminal traduit.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Touche
  {
    /// Une colonne vers la gauche.
    Gauche,
    /// Une colonne vers la droite.
    Droite,
    /// Au début du mot précédent (`Ctrl` + `←`).
    MotGauche,
    /// Au début du mot suivant (`Ctrl` + `→`).
    MotDroite,
    /// En début de ligne (`Début`).
    Debut,
    /// En fin de ligne (`Fin`).
    Fin,
    /// En début de ligne (`Page haut`) : le champ est mono-ligne, les
    /// pages n'y ont pas de sens et les extrêmes restent le geste utile.
    PageHaut,
    /// En fin de ligne (`Page bas`).
    PageBas,
    /// Supprime le caractère précédant (`Retour arrière`).
    Retour,
    /// Supprime le caractère sous le curseur (`Suppr`).
    Supprimer,
    /// Insère un caractère à la position du curseur.
    Caractere(char),
  }

/// Applique une touche au couple `(tampon, curseur)`.
///
/// `curseur` compte des caractères, pas des octets : les bornes sont
/// réalignées avant et après l'opération, un offset hors champ arrivant
/// quand la frappe remplace une sélection.
///
/// Retourne `true` si le tampon ou le curseur a bougé.
pub fn gerer(tampon: &mut String, curseur: &mut usize, touche: Touche) -> bool
  {
    let mut texte: Vec<char> = tampon.chars().collect();
    let depart = (*curseur).min(texte.len());
    let mut pos = depart;

    match touche
      {
        Touche::Gauche => pos = depart.saturating_sub(1),
        Touche::Droite => pos = (depart + 1).min(texte.len()),
        Touche::MotGauche => pos = debut_mot(&texte, depart),
        Touche::MotDroite => pos = fin_mot(&texte, depart),
        Touche::Debut | Touche::PageHaut => pos = 0,
        Touche::Fin | Touche::PageBas => pos = texte.len(),
        Touche::Retour =>
          {
            if depart > 0
              {
                texte.remove(depart - 1);
                pos = depart - 1;
              }
          }
        Touche::Supprimer =>
          {
            if depart < texte.len()
              {
                texte.remove(depart);
              }
          }
        Touche::Caractere(c) =>
          {
            texte.insert(depart, c);
            pos = depart + 1;
          }
      }

    let resultat: String = texte.into_iter().collect();
    let bouge = pos != depart || resultat != *tampon;
    *curseur = pos;
    *tampon = resultat;
    bouge
  }

/// Position du début du mot précédant `pos` (saut de mot standard : on
/// d'abord les espaces qui séparent, puis le mot lui-même).
fn debut_mot(texte: &[char], pos: usize) -> usize
  {
    let mut i = pos.min(texte.len());
    while i > 0 && texte[i - 1].is_whitespace()
      {
        i -= 1;
      }
    while i > 0 && !texte[i - 1].is_whitespace()
      {
        i -= 1;
      }
    i
  }

/// Position du début du mot suivant `pos` : on saute le mot courant puis
/// les espaces, comme le `Ctrl` + `→` d'un éditeur.
fn fin_mot(texte: &[char], pos: usize) -> usize
  {
    let mut i = pos.min(texte.len());
    while i < texte.len() && !texte[i].is_whitespace()
      {
        i += 1;
      }
    while i < texte.len() && texte[i].is_whitespace()
      {
        i += 1;
      }
    i
  }

#[cfg(test)]
mod tests
  {
    use super::*;

    /// Champ rempli, curseur en fin : la situation juste après `Entrée`.
    fn champ(texte: &str) -> (String, usize)
      {
        let tampon = texte.to_string();
        let curseur = texte.chars().count();
        (tampon, curseur)
      }

    #[test]
    fn la_frappe_continue_le_texte_sans_effacer()
      {
        let (mut tampon, mut curseur) = champ("description existante");
        gerer(&mut tampon, &mut curseur, Touche::Caractere('!'));
        assert_eq!(tampon, "description existante!");
        assert_eq!(curseur, 22, "à la fin du texte inséré");
      }

    /// L'écrasement global au premier caractère était le bug : la première
    /// frappe doit insérer, pas remplacer.
    #[test]
    fn la_premiere_frappe_insere_sans_effacer_le_texte()
      {
        let (mut tampon, mut curseur) = champ("1.0.0");
        gerer(&mut tampon, &mut curseur, Touche::Caractere('2'));
        assert_eq!(tampon, "1.0.02", "aucun écrasement");
      }

    #[test]
    fn retour_arriere_et_suppr_agissent_des_la_premiere_touche()
      {
        let (mut tampon, mut curseur) = champ("abc");
        gerer(&mut tampon, &mut curseur, Touche::Retour);
        assert_eq!(tampon, "ab");
        assert_eq!(curseur, 2);

        let (mut tampon, mut curseur) = champ("abc");
        gerer(&mut tampon, &mut curseur, Touche::Caractere('x'));
        gerer(&mut tampon, &mut curseur, Touche::Retour);
        gerer(&mut tampon, &mut curseur, Touche::Retour);
        gerer(&mut tampon, &mut curseur, Touche::Retour);
        assert_eq!(tampon, "a", "« abcx » moins trois retours");
        assert_eq!(curseur, 1);
        gerer(&mut tampon, &mut curseur, Touche::Retour);
        gerer(&mut tampon, &mut curseur, Touche::Retour);
        assert_eq!(tampon, "", "le champ finit vide sans erreur");
        assert_eq!(curseur, 0);
        // Au bout, la touche n'est pas une erreur : elle ne fait rien.
        let bouge = gerer(&mut tampon, &mut curseur, Touche::Retour);
        assert!(!bouge, "rien à supprimer");
      }

    #[test]
    fn suppr_efface_le_caractere_sous_le_curseur()
      {
        let (mut tampon, mut curseur) = champ("abcd");
        gerer(&mut tampon, &mut curseur, Touche::Gauche);
        gerer(&mut tampon, &mut curseur, Touche::Gauche);
        gerer(&mut tampon, &mut curseur, Touche::Supprimer);
        assert_eq!(tampon, "abd");
        assert_eq!(curseur, 2);
      }

    #[test]
    fn les_extremes_sont_les_bornes_de_la_ligne()
      {
        let (mut tampon, mut curseur) = champ("abc");
        gerer(&mut tampon, &mut curseur, Touche::Debut);
        assert_eq!(curseur, 0);
        gerer(&mut tampon, &mut curseur, Touche::Droite);
        gerer(&mut tampon, &mut curseur, Touche::Caractere('-'));
        assert_eq!(tampon, "a-bc");
        gerer(&mut tampon, &mut curseur, Touche::Fin);
        assert_eq!(curseur, tampon.chars().count());
        // Page haut/bas : le champ est mono-ligne, ce sont les mêmes extrêmes.
        gerer(&mut tampon, &mut curseur, Touche::PageHaut);
        assert_eq!(curseur, 0);
        gerer(&mut tampon, &mut curseur, Touche::PageBas);
        assert_eq!(curseur, tampon.chars().count());
      }

    #[test]
    fn les_sauts_de_mot_marchent_dans_les_deux_sens()
      {
        let (mut tampon, mut curseur) = champ("premier second troisieme");
        gerer(&mut tampon, &mut curseur, Touche::MotGauche);
        assert_eq!(curseur, 15, "début de « troisieme »");
        gerer(&mut tampon, &mut curseur, Touche::MotGauche);
        assert_eq!(curseur, 8, "début de « second »");
        gerer(&mut tampon, &mut curseur, Touche::MotDroite);
        assert_eq!(curseur, 15, "début de « troisieme »");
        gerer(&mut tampon, &mut curseur, Touche::MotDroite);
        assert_eq!(curseur, 24, "fin de la ligne");
        // Depuis le premier mot : saut direct en début de ligne.
        gerer(&mut tampon, &mut curseur, Touche::Debut);
        gerer(&mut tampon, &mut curseur, Touche::MotDroite);
        assert_eq!(curseur, 8);
      }

    /// Le champ peut contenir des accents : le curseur compte des
    /// caractères, l'insertion ne doit pas couper un octet de UTF-8.
    #[test]
    fn les_accents_ne_coupent_jamais_un_caractere()
      {
        let (mut tampon, mut curseur) = champ("héllo");
        gerer(&mut tampon, &mut curseur, Touche::Debut);
        gerer(&mut tampon, &mut curseur, Touche::MotDroite);
        assert_eq!(curseur, 5, "saut de mot sur « héllo » sans coupure");
        gerer(&mut tampon, &mut curseur, Touche::Debut);
        gerer(&mut tampon, &mut curseur, Touche::Caractere('é'));
        assert_eq!(tampon, "éhéllo");
        gerer(&mut tampon, &mut curseur, Touche::Retour);
        assert_eq!(tampon, "héllo");
      }

    /// Un offset hérité d'une sélection remplacée peut dépasser la longueur :
    /// il doit être réaligné, jamais paniquer.
    #[test]
    fn un_curseur_hors_bornes_est_realigne()
      {
        let mut tampon = "abc".to_string();
        let mut curseur = 99;
        let bouge = gerer(&mut tampon, &mut curseur, Touche::Gauche);
        assert_eq!(curseur, 2, "réaligné en fin de ligne");
        assert!(bouge);
        let mut tampon = String::new();
        let mut curseur = 4;
        gerer(&mut tampon, &mut curseur, Touche::Caractere('x'));
        assert_eq!(tampon, "x");
        assert_eq!(curseur, 1);
      }

    #[test]
    fn rien_changer_ne_renvoie_pas_vrai()
      {
        let (mut tampon, mut curseur) = champ("abc");
        gerer(&mut tampon, &mut curseur, Touche::Debut);
        let bouge = gerer(&mut tampon, &mut curseur, Touche::Gauche);
        assert!(!bouge, "déjà en début de ligne");
        let mut tampon = String::new();
        let mut curseur = 0;
        assert!(!gerer(&mut tampon, &mut curseur, Touche::Supprimer));
      }
  }
