//! Fond opaque et cadre de fenêtre flottante.
//!
//! Chaque popup répétait `Clear` puis un `Block` de fond noir — l'un oubliait
//! le `Clear`, un autre divisait la zone à la main. Un popup sans fond opaque
//! laisse transparaître le menu du dessous, ce qui rend le texte illisible.

use ratatui::{
    layout::Rect,
    style::Style,
    widgets::{Block, Borders, Clear},
    Frame,
};

use crate::theme::Popup;

/// Repeint `rect` d'un fond opaque : efface d'abord, sans quoi les styles du
/// contenu situé en dessous restent sous le texte du popup.
pub fn fond_opaque(f: &mut Frame, rect: Rect, theme: Popup)
  {
    f.render_widget(Clear, rect);
    f.render_widget(Block::default().style(Style::default().bg(theme.fond)), rect);
  }

/// Dessine le fond opaque et le cadre, et rend l'intérieur du cadre.
///
/// Le titre est renvoyé déjà encadré d'espaces, comme l'exige un titre de
/// popup lisible.
///
/// Renvoie l'intérieur : c'est là que le contenu doit aller. Les bordures
/// mangent deux lignes et deux colonnes, et les poser à côté produisait des
/// dialogues qui débordaient d'une ligne.
pub fn cadre(f: &mut Frame, rect: Rect, titre: &str, theme: Popup) -> Rect
  {
    fond_opaque(f, rect, theme);
    let bloc = Block::default()
      .title(format!(" {titre} "))
      .borders(Borders::ALL)
      .border_style(Style::default().fg(theme.bordure))
      .style(Style::default().bg(theme.fond));
    let inner = bloc.inner(rect);
    f.render_widget(bloc, rect);
    inner
  }

/// Même chose, avec un titre calculé à partir de l'état affiché.
pub fn cadre_titre<F>(f: &mut Frame, rect: Rect, titre: F, theme: Popup) -> Rect
  where
    F: FnOnce() -> String,
  {
    cadre(f, rect, &titre(), theme)
  }

#[cfg(test)]
mod tests
  {
    use super::*;
    use ratatui::{
      backend::TestBackend,
      buffer::Buffer,
      text::Line,
      widgets::Paragraph,
      Terminal,
    };

    fn texte(buf: &Buffer) -> String {
      (0..buf.area.height)
        .map(|y| {
          (0..buf.area.width).map(|x| buf[(x, y)].symbol()).collect::<String>()
        })
        .collect::<Vec<_>>()
        .join("\n")
    }

    fn rendre(l: u16, h: u16, theme: Popup) -> String {
      let mut term = Terminal::new(TestBackend::new(l, h)).unwrap();
      let rect = Rect { x: 2, y: 1, width: 20, height: 5 };
      term.draw(|f| {
        let inner = cadre(f, rect, "Test", theme);
        f.render_widget(Paragraph::new("X"), inner);
      })
      .unwrap();
      texte(term.backend().buffer())
    }

    #[test]
    fn le_cadre_affiche_son_titre_et_ses_bordures()
      {
        let rendu = rendre(30, 10, Popup::SOMBRE);
        assert!(rendu.contains(" Test "), "titre manquant :\n{rendu}");
        assert!(rendu.contains('┌') && rendu.contains('└'), "bordures manquantes :\n{rendu}");
      }

    /// Le contenu doit atterrir dans l'intérieur, pas sous les bordures.
    #[test]
    fn le_contenu_tombe_dans_l_interieur_du_cadre()
      {
        let mut term = Terminal::new(TestBackend::new(30, 10)).unwrap();
        let rect = Rect { x: 2, y: 1, width: 20, height: 5 };
        let mut inner = Rect::default();
        term.draw(|f| {
          inner = cadre(f, rect, "T", Popup::SOMBRE);
          f.render_widget(Paragraph::new("X"), inner);
        })
        .unwrap();
        let buf = term.backend().buffer();
        assert_eq!((inner.x, inner.y), (3, 2));
        assert_eq!((inner.width, inner.height), (18, 3));
        // Le X ne doit pas avoir mangé la bordure du haut. La colonne visée est
        // décalée : le titre occupe les premières colonnes de cette ligne.
        assert_eq!(buf[(inner.x + 3, inner.y - 1)].symbol(), "─");
        assert_eq!(buf[(inner.x, inner.y)].symbol(), "X");
      }

    /// Un popup posé sur du contenu doit le masquer entièrement.
    #[test]
    fn le_fond_opaque_masque_le_contenu_en_dessous()
      {
        let mut term = Terminal::new(TestBackend::new(30, 10)).unwrap();
        term.draw(|f| {
          let lignes: Vec<Line> = (0..f.area().height)
            .map(|_| Line::from("MENU".repeat(10)))
            .collect();
          f.render_widget(Paragraph::new(lignes), f.area());
          cadre(f, Rect { x: 2, y: 1, width: 20, height: 5 }, "T", Popup::SOMBRE);
        })
        .unwrap();
        let buf = term.backend().buffer().clone();
        // Le menu reste visible en dehors du popup : c'est le but.
        assert!(texte(&buf).contains("MENU"), "le fond d'écran doit rester visible");
        // Aucune colonne du popup ne doit laisser voir le menu.
        let mut fuite = Vec::new();
        for y in 1..6
          {
            for x in 2..22
              {
                let c = buf[(x, y)].symbol();
                if c.contains('M') || c.contains('E') || c.contains('N') || c.contains('U')
                  {
                    fuite.push(format!("({x},{y})={c}"));
                  }
              }
          }
        assert!(fuite.is_empty(), "le fond a laissé passer le menu : {fuite:?}");
      }

    #[test]
    fn le_titre_prend_la_ligne_du_premier_caractere()
      {
        let mut term = Terminal::new(TestBackend::new(30, 10)).unwrap();
        let mut inner = Rect::default();
        term.draw(|f| {
          inner = cadre_titre(f, Rect { x: 2, y: 1, width: 20, height: 5 }, || "Calcul".to_string(), Popup::SOMBRE);
        })
        .unwrap();
        assert_eq!(inner.width, 18);
        assert!(texte(term.backend().buffer()).contains(" Calcul "));
      }
  }
